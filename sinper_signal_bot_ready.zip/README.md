# Sniper Signal Bot

This is a simple Telegram bot for binary trading alerts.